This is a flask app with user authentication and session management which takes data from different sites and display it on your page.

Status: In Progress

Demo:


https://github.com/user-attachments/assets/728aee24-a21b-41b9-98aa-24b982883f2c

